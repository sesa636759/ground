import { DemoSidebarComponent } from '../../shared/components/demo-sidebar/demo-sidebar.component';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AppInputValueAccessorDirective } from '../../directives/app-input-value-accessor.directive';
import { AppCheckboxValueAccessorDirective } from '../../directives/app-checkbox-value-accessor.directive';
import { TimerPlaygroundComponent } from './components/timer-playground/timer-playground.component';
import { DemoTabsComponent } from '../../shared/demo-tabs/demo-tabs.component';
import { ComponentDocumentationComponent } from '../../pages/component-documentation/component-documentation.component';
import { DemoHeaderComponent } from '../../shared/components/demo-header/demo-header.component';

@Component({
  selector: 'app-app-timer-demo',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    TimerPlaygroundComponent,
    DemoTabsComponent,
    DemoSidebarComponent,
    ComponentDocumentationComponent,
    DemoHeaderComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './app-timer-demo.component.html',
  styleUrl: './app-timer-demo.component.scss',
})
export class AppTimerDemoComponent {
  variants = [
    { id: 'playground', name: 'Playground', icon: '🎮', color: '#8b5cf6' },
    { id: 'modes', name: 'Timer Modes', icon: '⏲️', color: '#3b82f6' },
    { id: 'formats', name: 'Display Formats', icon: '🕰️', color: '#10b981' },
  ];

  get exampleVariants() {
    return this.variants.filter((v) => v.id !== 'playground');
  }

  playgroundCode = `<ui-timer [duration]="60" mode="countdown" format="mm:ss"></ui-timer>`;

  modesCode = `<!-- Countdown from 5 mins -->
<ui-timer mode="countdown" [duration]="300"></ui-timer>

<!-- Stopwatch -->
<ui-timer mode="stopwatch"></ui-timer>`;

  formatsCode = `<!-- Seconds Only -->
<ui-timer format="ss"></ui-timer>

<!-- Full Timestamp -->
<ui-timer format="HH:mm:ss"></ui-timer>`;

  scrollToSection(id: string) {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
}
