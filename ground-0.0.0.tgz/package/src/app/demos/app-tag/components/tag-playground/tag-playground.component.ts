﻿import { Component, CUSTOM_ELEMENTS_SCHEMA, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AppCheckboxValueAccessorDirective } from '../../../../directives/app-checkbox-value-accessor.directive';

@Component({
  selector: 'app-tag-playground',
  standalone: true,
  imports: [CommonModule, FormsModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <div class="playground-layout">
      <div class="playground-controls">
    <ui-accordion items='[{"id":"config","title":"Configuration","icon":"⚙️"}]' defaultOpen='["config"]' multiple>
      <div slot="content-config">
        <div class="control-grid">
          <div class="control-section">
            <h3>Visuals</h3>
            <div class="control-group">
              <label>Value / Text</label>
              <input type="text" [(ngModel)]="pgConfig.value" (ngModelChange)="updateConfig()" />
            </div>
            <div class="control-group">
              <label>Icon</label>
              <input type="text" [(ngModel)]="pgConfig.icon" (ngModelChange)="updateConfig()" />
            </div>
            <div class="control-group">
              <label>Severity</label>
              <ui-dropdown
                [(ngModel)]="pgConfig.severity"
                (ngModelChange)="updateConfig()"
                [options]="severityOptions"
              ></ui-dropdown>
            </div>
          </div>

          <div class="control-section">
            <h3>Styling</h3>
            <div class="checkpoint-group">
              <app-checkbox
                id="rounded"
                [(ngModel)]="pgConfig.rounded"
                (ngModelChange)="updateConfig()"
                label="Rounded Corners"
              ></app-checkbox>
            </div>
            <div class="control-group">
              <label>Size</label>
              <ui-dropdown
                [(ngModel)]="pgConfig.size"
                (ngModelChange)="updateConfig()"
                [options]="sizeOptions"
              ></ui-dropdown>
            </div>
          </div>
        </div>

        

        <div class="action-buttons">
          <ui-button
            class="btn-secondary"
            variant="secondary"
            (click)="resetConfig()"
            label="Reset"
          ></ui-button>
        </div>
            </div>
    </ui-accordion>
  </div>

  <div class="playground-preview">
        <ui-tag
          [attr.value]="pgConfig.value"
          [attr.icon]="pgConfig.icon"
          [attr.severity]="pgConfig.severity"
          [attr.rounded]="pgConfig.rounded ? '' : null"
          [attr.size]="pgConfig.size"
        ></ui-tag>
      
      <div class="code-output">
          <ui-code-preview
            [htmlCode]="generatedCode()"
            label="Generated Code"
            activeLang="html"
            expanded="true"
          ></ui-code-preview>
        </div>
    </div>
    </div>
  `,
  styleUrl: './tag-playground.component.scss',
})
export class TagPlaygroundComponent {
  pgConfig = {
    value: 'New Update',
    icon: '⚡',
    severity: 'info',
    rounded: true,
    size: 'small',
  };

  severityOptions = [
    { label: 'Info', value: 'info' },
    { label: 'Success', value: 'success' },
    { label: 'Warning', value: 'warning' },
    { label: 'Danger', value: 'danger' },
  ];

  sizeOptions = [
    { label: 'Small', value: 'small' },
    { label: 'Large', value: 'large' },
  ];

  generatedCode = signal('');

  constructor() {
    this.updateConfig();
  }

  updateConfig() {
    let code = '<ui-tag\n';
    code += `  value="${this.pgConfig.value}"\n`;
    code += `  severity="${this.pgConfig.severity}"\n`;
    if (this.pgConfig.rounded) code += `  rounded\n`;
    if (this.pgConfig.icon) code += `  icon="${this.pgConfig.icon}"\n`;
    code += '></ui-tag>';

    this.generatedCode.set(code);
  }

  copyCode() {
    navigator.clipboard.writeText(this.generatedCode());
  }

  resetConfig() {
    this.pgConfig = {
      value: 'New Update',
      icon: '⚡',
      severity: 'info',
      rounded: true,
      size: 'small',
    };
    this.updateConfig();
  }
}
