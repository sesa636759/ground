import { DemoSidebarComponent } from '../../shared/components/demo-sidebar/demo-sidebar.component';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AsidePlaygroundComponent } from './components/aside-playground/aside-playground.component';
import { DemoTabsComponent } from '../../shared/demo-tabs/demo-tabs.component';
import { ExampleSectionComponent } from '../../shared/components/example-section/example-section.component';
import { DemoHeaderComponent } from '../../shared/components/demo-header/demo-header.component';
import { ComponentDocumentationComponent } from '../../pages/component-documentation/component-documentation.component';
import { BaseDemoComponent } from '../../shared/base-demo.component';

@Component({
  selector: 'app-app-aside-demo',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    AsidePlaygroundComponent,
    DemoTabsComponent,
    ExampleSectionComponent,
    DemoHeaderComponent,
    ComponentDocumentationComponent,
    DemoSidebarComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './app-aside-demo.component.html',
  styleUrl: './app-aside-demo.component.scss',
})
export class AppAsideDemoComponent extends BaseDemoComponent {
  variants = [
    { id: 'directions', title: 'Directions', icon: '🧭' },
    { id: 'visual-styles', title: 'Visual Styles', icon: '🎨' },
    { id: 'resizable', title: 'Resizable', icon: '↔️' },
    { id: 'close-behavior', title: 'Close Behavior', icon: '🚪' },
  ];

  get exampleVariants() {
    return this.variants;
  }

  anchorLinks = JSON.stringify(
    this.variants.map((v) => ({
      id: v.id,
      label: v.title,
      target: v.id,
      icon: v.icon,
    })),
  );

  sidebars = {
    left: false,
    right: false,
    top: false,
    bottom: false,
    glass: false,
    default: false,
    resizable: false,
    escClose: false,
    overlayClose: false,
  };

  // Code Snippets
  directionsCode = `<!-- Left (default) -->
<aside-panel direction="left" [open]="leftOpen" (asideClosed)="leftOpen = false">
  <div slot="header"><h3>Left Panel</h3></div>
  <div slot="content">Navigation links or profile info.</div>
</aside-panel>

<!-- Right -->
<aside-panel direction="right" [open]="rightOpen" (asideClosed)="rightOpen = false">
  <div slot="header"><h3>Right Panel</h3></div>
  <div slot="content">Details, filters, or settings.</div>
</aside-panel>

<!-- Top -->
<aside-panel direction="top" size="200px" [open]="topOpen" (asideClosed)="topOpen = false">
  <div slot="header"><h3>Announcement</h3></div>
  <div slot="content">A top bar for notices or notifications.</div>
</aside-panel>

<!-- Bottom -->
<aside-panel direction="bottom" size="300px" [open]="bottomOpen" (asideClosed)="bottomOpen = false">
  <div slot="header"><h3>Media Player</h3></div>
  <div slot="content">Bottom panels for media controls or mobile menus.</div>
</aside-panel>`;

  visualStylesCode = `<!-- Default solid panel -->
<aside-panel [open]="defaultOpen" (asideClosed)="defaultOpen = false">
  <div slot="header"><h3>Default Panel</h3></div>
  <div slot="content">Clean, solid background with standard styling.</div>
</aside-panel>

<!-- Glassmorphism panel -->
<aside-panel variant="glass" backdrop-blur="12px" [open]="glassOpen" (asideClosed)="glassOpen = false">
  <div slot="header"><h3>Glass Panel</h3></div>
  <div slot="content">Translucent with blur backdrop for a premium feel.</div>
</aside-panel>`;

  resizableCode = `<!-- Resizable panel with min/max constraints -->
<aside-panel
  resizable
  min-size="200"
  max-size="700"
  size="400px"
  [open]="resizableOpen"
  (asideClosed)="resizableOpen = false"
>
  <div slot="header"><h3>Resizable Panel</h3></div>
  <div slot="content">Drag the edge to resize between 200px and 700px.</div>
</aside-panel>`;

  closeBehaviorCode = `<!-- Close on Escape key -->
<aside-panel close-on-escape [open]="escOpen" (asideClosed)="escOpen = false">
  <div slot="content">Press Escape to dismiss.</div>
</aside-panel>

<!-- Close on overlay click -->
<aside-panel close-on-overlay-click [open]="overlayOpen" (asideClosed)="overlayOpen = false">
  <div slot="content">Click outside the panel to close.</div>
</aside-panel>`;

  togglePanel(key: keyof typeof AppAsideDemoComponent.prototype.sidebars) {
    this.sidebars[key] = !this.sidebars[key];
  }
}
