# PowerShell script to refactor demo SCSS files to use shared demo-base.scss

$demoFiles = Get-ChildItem -Path "src\app\demos" -Recurse -Filter "*-demo.component.scss" | Where-Object { $_.FullName -notlike "*\components\*" }

$standardContent = @'
@use '../../../styles/playground-base.scss';

.demo-container {
  max-width: 90%;
  margin: 0 auto;
  padding: 40px 24px;
}

h1 {
  font-size: 2.5rem;
  font-weight: 800;
  color: var(--text-primary);
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 12px;
}

.intro-text {
  font-size: 1.125rem;
  color: var(--text-secondary);
  margin-bottom: 32px;
  line-height: 1.6;
}

.variants-nav {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  padding: 8px 4px 24px 4px;
  margin-bottom: 40px;

  .variant-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.2s;
    &:hover { transform: translateY(-2px); }
  }
}

.demo-section {
  margin-bottom: 64px;
  scroll-margin-top: 20px;
}

.section-header {
  margin-bottom: 24px;
  h2 { font-size: 1.75rem; font-weight: 700; color: var(--text-primary); margin-bottom: 8px; }
  p { font-size: 1rem; color: var(--text-secondary); margin: 0; }
}

.demo-card {
  background: var(--surface-1);
  border: 1px solid var(--border-color);
  border-radius: 16px;
  overflow: hidden;
  padding: 40px;
  display: flex;
  flex-direction: column;
  gap: 32px;
}
'@

$replacementImport = "@use '../../../styles/demo-base.scss';"

foreach ($file in $demoFiles) {
    $content = Get-Content $file.FullName -Raw
    
    # Check if file contains the standard duplicate content
    if ($content -match "\.demo-container\s*\{" -and $content -match "\.variants-nav\s*\{") {
        Write-Host "Processing: $($file.Name)"
        
        # Extract any custom styles after .demo-card
        if ($content -match '\.demo-card\s*\{[^}]*\}(.*)$') {
            $customStyles = $matches[1].Trim()
        } else {
            $customStyles = ""
        }
        
        # Replace with import
        $newContent = $replacementImport
        if ($customStyles) {
            $newContent += "`r`n`r`n" + $customStyles
        }
        
        Set-Content -Path $file.FullName -Value $newContent -NoNewline
        Write-Host "  ✓ Refactored: $($file.Name)"
    }
}

Write-Host "`nRefactoring complete!"
